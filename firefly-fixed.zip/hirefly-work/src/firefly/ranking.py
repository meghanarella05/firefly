def rank(scores):
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)
