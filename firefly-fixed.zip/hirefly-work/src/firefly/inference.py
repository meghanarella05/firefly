def extract_evidence(text, model):
    text = text.lower()
    evidence = {}

    for variable, patterns in model["observable"].items():
        matches = [p for p in patterns if p in text]
        evidence[variable] = {
            "strength": min(1.0, 0.35 * len(matches)),
            "status": "SUPPORTED" if matches else "UNKNOWN",
            "matches": matches,
        }

    return evidence


def infer(evidence, model):
    scores = {
        variable: data["strength"]
        for variable, data in evidence.items()
    }

    # Deterministic forward propagation through positive research edges.
    for _ in range(2):
        for rel in model["relationships"]:
            if rel["direction"] != "positive":
                continue

            source = rel["source"]
            target = rel["target"]

            if source in scores:
                propagated = scores[source] * rel["strength"]
                scores[target] = max(scores.get(target, 0.0), propagated)

    return scores
