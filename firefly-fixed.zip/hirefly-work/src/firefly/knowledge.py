DICTIONARY = {
    "teamwork": "collaboration",
    "collaboration": "collaboration",
    "cooperation": "collaboration",
    "persistence": "persistence",
    "task persistence": "persistence",
    "self regulation": "self_regulation",
    "self-regulation": "self_regulation",
    "communication": "communication",
    "technical skill": "technical_depth",
    "technical depth": "technical_depth",
    "project ownership": "ownership",
    "ownership": "ownership",
    "job performance": "job_performance",
}


def canonical(term):
    key = term.strip().lower()
    return DICTIONARY.get(key, key.replace(" ", "_"))


def build_model(studies):
    variables = set()
    relationships = []
    observable = {}

    for study in studies:
        for variable in study.get("variables", []):
            variables.add(canonical(variable))

        for rel in study.get("relationships", []):
            relationships.append({
                "source": canonical(rel["source"]),
                "target": canonical(rel["target"]),
                "strength": float(rel.get("strength", 0.5)),
                "direction": rel.get("direction", "positive"),
            })

        for item in study.get("observable", []):
            key = canonical(item["variable"])
            observable.setdefault(key, []).append(
                item["pattern"].lower()
            )

    return {
        "variables": sorted(variables),
        "relationships": relationships,
        "observable": observable,
        "dictionary": DICTIONARY,
    }
