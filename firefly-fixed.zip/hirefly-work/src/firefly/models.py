from dataclasses import dataclass

@dataclass(frozen=True)
class RankedItem:
    item: str
    score: float
    rank: int
    percentile: float
    explanation: str

@dataclass(frozen=True)
class Result:
    results: list[RankedItem]
    corpus_size: int
    variables: list[str]
