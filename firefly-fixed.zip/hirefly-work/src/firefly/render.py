from .models import RankedItem


def render(scores):
    n = len(scores)
    output = []

    for index, (variable, score) in enumerate(scores, start=1):
        percentile = round(100 * (n - index + 1) / n, 1) if n else 0.0

        output.append(
            RankedItem(
                item=variable.replace("_", " ").title(),
                score=round(score, 4),
                rank=index,
                percentile=percentile,
                explanation=(
                    f"Deterministic evidence score for "
                    f"{variable.replace('_', ' ')}."
                ),
            )
        )

    return output
