# Hirefly

**Deterministic research → evidence → inference → ranking.**

Hirefly is a lightweight Python library for turning a structured research corpus into reproducible decision support.

No LLM dependency. No vector database. No agent framework.

## Install

```bash
pip install hirefly
```

## Example

```python
from hirefly import Hirefly

hf = Hirefly()

result = hf.analyze(
    goal="junior frontend developer performance",
    text="Built and maintained a React application for 18 months. Collaborated with a team."
)

for item in result.results:
    print(item.item, item.score, item.percentile)
```

## Design

```text
input
  ↓
observable evidence
  ↓
canonical variables
  ↓
research relationships
  ↓
deterministic inference
  ↓
score / rank
  ↓
natural-language explanation
```

The included corpus is a **demonstration corpus**, not a validated employment predictor.

## Development

```bash
python -m pip install -e ".[dev]"
pytest
python -m build
```
