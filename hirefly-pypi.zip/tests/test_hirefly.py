from hirefly import Hirefly


def test_package_imports():
    assert Hirefly


def test_analyze_returns_ranked_results():
    hf = Hirefly()
    result = hf.analyze(
        goal="junior frontend performance",
        text="Built a React project, collaborated with a team, maintained it for 18 months."
    )
    assert result.results
    assert result.results[0].rank == 1


def test_unknown_evidence_does_not_become_positive_evidence():
    hf = Hirefly()
    result = hf.analyze(
        goal="junior frontend performance",
        text="This resume contains no matching evidence."
    )
    assert all(item.score >= 0 for item in result.results)


def test_deterministic_output():
    hf = Hirefly()
    a = hf.analyze(text="Built and maintained a project with a team.")
    b = hf.analyze(text="Built and maintained a project with a team.")
    assert a == b
