from dataclasses import dataclass
from pathlib import Path
import json
from .knowledge import build_model
from .inference import extract_evidence, infer
from .ranking import rank
from .render import render


@dataclass(frozen=True)
class RankedItem:
    item: str
    score: float
    rank: int
    percentile: float
    explanation: str


@dataclass(frozen=True)
class Result:
    results: list[RankedItem]
    corpus_size: int
    variables: list[str]


class Hirefly:
    def __init__(self, corpus=None):
        if corpus is None:
            path = Path(__file__).parent / "data" / "sample_corpus.json"
            corpus = json.loads(path.read_text(encoding="utf-8"))
        self.corpus = corpus
        self.model = build_model(corpus)

    def analyze(self, goal="", text="", constraints="", keywords=None):
        keywords = keywords or []
        selected = self._select(keywords)
        model = build_model(selected)
        evidence = extract_evidence(
            text=f"{text} {goal} {constraints}",
            model=model
        )
        scores = infer(evidence, model)
        ranked = rank(scores)
        rendered = render(ranked)
        return Result(
            results=rendered,
            corpus_size=len(selected),
            variables=model["variables"],
        )

    def _select(self, keywords):
        if not keywords:
            return self.corpus
        keys = {k.lower() for k in keywords}
        selected = []
        for study in self.corpus:
            blob = (
                study.get("title", "") + " " +
                " ".join(study.get("variables", []))
            ).lower()
            if any(k in blob for k in keys):
                selected.append(study)
        return selected or self.corpus
